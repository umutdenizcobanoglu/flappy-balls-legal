ZIP dosyasini ayiklayip HTML dosyasini Chrome ile acin. Yeni ulkelerin cevrimici kullanimi icin gameApi katalog guncellemesi gereklidir.
