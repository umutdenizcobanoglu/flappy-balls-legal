ZIP dosyasini ayiklayip HTML dosyasini Chrome ile acin. Gercek AdMob reklamlari sadece Android LIVE-ADS APK icindir. Sandiklar hesap, dogrulanmis online ucus ve sunucu onayli reklam odulu gerektirir.
